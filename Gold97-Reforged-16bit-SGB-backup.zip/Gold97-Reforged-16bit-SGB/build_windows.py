from hashlib import md5
from pathlib import Path
from sys import argv

operation, filename, *arguments = argv[1:]
path = Path(filename)
if operation == 'hash':
    print(md5(path.read_bytes()).hexdigest()[:8])
elif operation == 'join':
    path.write_bytes(b''.join(Path(source).read_bytes() for source in arguments))
elif operation == 'frame':
    with path.open('ab') as destination:
        destination.write(('\tdb ' + ', '.join('$' + x for x in arguments) + '\n').encode('ascii'))

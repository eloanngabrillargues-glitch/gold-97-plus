param(
    [string]$RgbdsDirectory,
    [ValidateRange(1, 32)][int]$Jobs = 4
)

$ErrorActionPreference = 'Stop'
$previousPath = $env:Path
Push-Location -LiteralPath $PSScriptRoot
try {
    if ($RgbdsDirectory) {
        $resolvedRgbds = (Resolve-Path -LiteralPath $RgbdsDirectory).Path
        $env:Path = "$resolvedRgbds;$env:Path"
    }

    foreach ($program in 'rgbasm', 'rgblink', 'rgbfix', 'rgbgfx', 'gcc', 'python') {
        if (-not (Get-Command $program -ErrorAction SilentlyContinue)) {
            throw "Programme introuvable dans PATH : $program"
        }
    }
    $version = & rgbasm --version
    if ($LASTEXITCODE -ne 0 -or $version -notmatch '0\.4\.1\b') {
        throw "RGBDS 0.4.1 requis. Version trouvee : $version"
    }
    $nativeMake = Get-Command mingw32-make.exe -ErrorAction SilentlyContinue
    if (-not $nativeMake) {
        $nativeMake = Get-Command make.exe -ErrorAction SilentlyContinue
    }
    if (-not $nativeMake) {
        throw 'GNU Make pour Windows introuvable dans PATH.'
    }

    foreach ($source in Get-ChildItem -LiteralPath tools -Filter '*.c') {
        & gcc -O3 -std=c99 -Wall -Wextra -o "tools/$($source.BaseName).exe" $source.FullName
        if ($LASTEXITCODE) {
            throw "Echec de compilation de $($source.Name)."
        }
    }

    & $nativeMake.Source -f Makefile.windows gold "-j$Jobs" -W constants/pokemon_constants.asm SPECIES_PORT_TEST=0
    if ($LASTEXITCODE) {
        throw "Echec de compilation de la ROM, code $LASTEXITCODE."
    }
    Get-FileHash -LiteralPath pokegold97.gbc -Algorithm SHA256
}
finally {
    Pop-Location
    $env:Path = $previousPath
}

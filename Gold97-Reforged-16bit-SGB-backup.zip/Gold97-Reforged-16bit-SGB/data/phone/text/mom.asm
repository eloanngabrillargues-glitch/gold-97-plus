MomPhoneGreetingText:
	text "Hello?"

	para "Oh, hi, <PLAYER>!"
	line "Working hard?"
	done

MomPhoneLandmarkText:
	text "Oh, so you're in"
	line "@"
	text_ram wStringBuffer3
	text "…"

	para "Isn't that where"
	line "@"
	text_ram wStringBuffer4
	text_start
	para "is? Did you go"
	line "take a look?"
	done

MomPhoneGenericAreaText:
	text "Really, you're in"
	line "@"
	text_ram wStringBuffer3
	text "?"

	para "I've never gone"
	line "there. That's kind"
	cont "of neat, <PLAYER>."
	done

MomPhoneNewBarkText:
	text "What? You're in"
	line "@"
	text_ram wStringBuffer3
	text "?"

	para "Come see your"
	line "<MOM> soon!"
	done

MomPhoneIndigoText:
	text "You're up on"
	line "@"
	text_ram wStringBuffer3
	text "?"

	para "I'm so proud of"
	line "you, dear!"
	done

MomPhoneCherrygroveText:
	text "You're up in"
	line "@"
	text_ram wStringBuffer3
	text "?"

	para "I'm so proud of"
	line "you, dear!"
	done
	
MomPhoneSilentHillsText:
	text "You're over in"
	line "@"
	text_ram wStringBuffer3
	text "?"

	para "How about coming"
	line "home for a bit?"
	done

MomOtherAreaText:
	text "Wow, you're in"
	line "@"
	text_ram wStringBuffer3
	text "?"

	para "Good luck on your"
	line "#MON quest!"
	done

MomDeterminedText:
	text "That sounds really"
	line "tough."

	para "But, <PLAYER>, I"
	line "know you're really"

	para "determined. You'll"
	line "be OK, right?"
	done

MomCheckBalanceText:
	text "By the way, you've"
	line "saved up ¥@"
	text_ram wStringBuffer3
	text "."

	para "Do you want to"
	line "keep on saving?"
	done

MomImportantToSaveText:
	text "It's important to"
	line "save your money."
	done

MomYoureNotSavingText:
	text "Oh, <PLAYER>,"
	line "you're not saving"

	para "any money. Would"
	line "you like to save?"
	done

MomYouveSavedText:
	text "By the way, you've"
	line "saved up ¥@"
	text_ram wStringBuffer3
	text "."

	para "Want to start"
	line "saving again?"
	done

MomOKIllSaveText:
	text "OK. I'll save your"
	line "money."
	done

MomPhoneWontSaveMoneyText:
	text "OK. I won't save"
	line "your money."
	done

MomPhoneHangUpText:
	text "<PLAYER>, keep it"
	line "up! I'm rooting"
	cont "for you, baby!"
	done

MomPhoneNoPokemonText:
	text "Hello?"

	para "Oh, hi, <PLAYER>!"
	line "Wasn't PROF.OAK"
	cont "waiting for you?"
	done

MomPhoneNoPokedexText:
	text "Hello?"

	para "Oh, hi, <PLAYER>!"
	line "You're on a big"

	para "mission for PROF."
	line "OAK? Be good!"
	done

MomPhoneLectureText:
	text "Hello?"

	para "…… <PLAYER>?"
	line "I heard from PROF."

	para "OAK that you went"
	line "on a long trip."

	para "I wish you would"
	line "have told me…"

	para "What about money?"
	line "Should I save it?"
	done

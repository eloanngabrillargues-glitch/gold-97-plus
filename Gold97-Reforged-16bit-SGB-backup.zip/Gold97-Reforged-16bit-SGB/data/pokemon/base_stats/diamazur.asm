	db LOW(DIAMAZUR) ; 254

	db  101, 144,  105,  90, 110, 110
	;   hp  atk  def  spd  sat  sdf

	db WATER, DRAGON ; types
	db 3 ; catch rate
	db 218 ; base exp
	db NO_ITEM, DRAGON_FANG ; items
	db GENDER_UNKNOWN ; gender ratio
	db 100 ; unknown 1
	db 40 ; step cycles to hatch
	db 5 ; unknown 2
	INCBIN "gfx/pokemon/diamazur/front.dimensions"
	db 0, 0, 0, 0 ; padding
	db GROWTH_SLOW ; growth rate
	dn EGG_NONE, EGG_NONE ; egg groups

	; tm/hm learnset
	tmhm HEADBUTT, ROAR, TOXIC, HIDDEN_POWER, BLIZZARD, HYPER_BEAM, ICY_WIND, PROTECT, RAIN_DANCE, ENDURE, IRON_TAIL, DRAGONBREATH, RETURN, DOUBLE_TEAM, SWAGGER, SLEEP_TALK, REST, SURF, STRENGTH, ROCK_SMASH, WHIRLPOOL, WATERFALL, ICE_BEAM
	; end
